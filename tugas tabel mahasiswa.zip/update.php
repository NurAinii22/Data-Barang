<?php
// koneksi database
include 'koneksi.php';
//Memproses data saat form di submit
if(isset($_POST["Npm"]) && !empty($_POST["Npm"])){
// menangkap data yang di kirim dari form
$npm = $_POST['Npm'];
$nama = $_POST['Nama'];
$jns_kelamin = $_POST['jekel'];
$jurusan = $_POST['jurusan'];
$kelas = $_POST['Kelas'];
// mengupdate data ke database
$update=mysqli_query($koneksi,"UPDATE datamahasiswa SET
Nama='$nama',jns_kelamin='$jns_kelamin',Kelas='$kelas',Jurusan='$jurusan'
WHERE Npm='$npm'")or die(mysqli_error());
if($update){
header("ubah.php");
}else{
echo'Gagal menyimpan data! ';
echo'<a href="ubah.php">Kembali</a>';
} 
}
