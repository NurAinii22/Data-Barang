<?php 
$koneksi = mysqli_connect("localhost","root","","akademik");   
if (mysqli_connect_errno()){
echo " koneksi Gagal : " . mysqli_connect_error();
}

else{
        $npm = $_POST['npm'];
        $nama = $_POST['nama'];
        $jns_kelamin = $_POST['jekel'];
        $jurusan = $_POST['jurusan']; 
        $kelas = $_POST['kelas'];

        
        $query = mysqli_query($koneksi, "INSERT INTO datamahasiswa (npm,nama,jns_kelamin,Jurusan,kelas) VALUES('$npm','$nama','$jns_kelamin','$jurusan','kelas')");
       if ($query)
       	echo "INPUT DATA SUKSES<br>";
       else
       	echo "INPUT DATA GAGAL<br>";
}
?>