<!DOCTYPE html>
<html>
<head>
<title>DATA MAHASISWA</title>
</head>
<body>
<h2>DATA MAHASISWA</h2>
<br/>
<a href="tambahmhs.php"> + TAMBAH MAHASISWA</a>
<br/>
<br/>
<table border="1" cellpadding="10">
<tr>
<th>No</th>
<th>NPM</th>
<th>Nama</th>
<th>jns_kelamin</th>
<th>Jurusan</th>
<th>Kelas</th>
</tr>
<?php
include 'koneksi.php';
$no = 1;
$data = mysqli_query($koneksi,"select * from datamahasiswa");
while($d = mysqli_fetch_array($data))
{
?>
<tr>
<td><?php echo $no++; ?></td>
<td><?php echo $d['Npm']; ?></td>
<td><?php echo $d['Nama']; ?></td>
<td><?php echo $d['jns_kelamin']; ?></td>
<td><?php echo $d['Jurusan']; ?></td>
<td><?php echo $d['Kelas']; ?></td>
<td>
<a href="ubah.php?id=<?php echo $d['Npm']; ?>">EDIT</a> |
<a href="hapus.php?id=<?php echo $d['Npm']; ?>">HAPUS</a>
</td>
</tr>
<?php
}
?>
</table>
</body>
</html>