<?php
if(isset($_GET['id'])){
include('koneksi.php');
$Npm=$_GET['id'];
$del=mysqli_query($koneksi,"DELETE FROM datamahasiswa WHERE
Npm='$Npm'");
if($del){
echo'Data mahasiswa berhasil dihapus! ';
echo'<a href="index.php">Kembali</a>';
}else{
echo'Gagal menghapus data! ';
echo'<a href="index.php">Kembali</a>';
}
}
?>