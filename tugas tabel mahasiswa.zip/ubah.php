<!DOCTYPE html>
<html>
<head>
<title>DATA MAHASISWA</title>
</head>
<body> <CENTER>
<table width="600" border="3" backgound_color="salmon"> </table>
<h2>DATA MAHASISWA</h2>
<br/>
<a href="index.php">KEMBALI</a>
<br/>
<br/>
<h3>EDIT DATA MAHASISWA</h3>
<?php
include 'koneksi.php';
$id = $_GET['id'];
$data = mysqli_query($koneksi,"select * from datamahasiswa where Npm='$id'");
while ($d = mysqli_fetch_array($data)){
?>

<form method="post" action="update.php">
<table>
<tr>
<td>Npm</td>
<td>
<input type="text" name="Npm" value="<?php echo

$d['Npm']; ?>"> </td>
</tr>
<tr>
<td>Nama</td>
<td><input type="text" name="Nama" value="<?php echo

$d['Nama']; ?>"></td>
</tr>
<tr>
<td>Jenis Kelamin</td>
<td>
<input type="radio" name="jekel" value="L" <?php
if($d['jns_kelamin']=='L') echo 'checked'?>>Laki-laki

<input type="radio" name="jekel" value="P" <?php
if($d['jns_kelamin']=='P') echo 'checked'?>>Perempuan
</td>
</tr> <tr>
<td> Jurusan </td>
<td>
<Select name=jurusan>
<option value="SI" <?php if($d['Jurusan']=="SI") echo

'selected="selected"'; ?> >SI</option>

<option value="TI" <?php if($d['Jurusan']=="TI") echo

'selected="selected"'; ?> >TI</option>

<option value="SIA" <?php if($d['Jurusan']=="SIA") echo

'selected="selected"'; ?> >SIA</option>

</select>
</td>
</tr>
<tr>
<td>Kelas</td>
<td><input type="text" name="Kelas" value="<?php echo

$d['Kelas']; ?>"></td>
</tr>
<tr>
<td></td>
<td>
<input name="BtnSimpan" type="submit" value="SIMPAN">
<input name="BtnBatal" type="reset" value="BATAL" />
</td>
</tr>
</table>
</form>
<?php
}
?>
</body>
</html>